-- Neue UUID-Spalte für Werkzeuge
ALTER TABLE tools ADD COLUMN uuid TEXT DEFAULT (lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || substr('89ab',abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6))));
CREATE UNIQUE INDEX idx_tools_uuid ON tools(uuid);

-- Neue UUID-Spalte für Verbrauchsmaterial
ALTER TABLE consumables ADD COLUMN uuid TEXT DEFAULT (lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || substr('89ab',abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6))));
CREATE UNIQUE INDEX idx_consumables_uuid ON consumables(uuid);

-- Neue UUID-Spalte für Mitarbeiter
ALTER TABLE workers ADD COLUMN uuid TEXT DEFAULT (lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' || substr(lower(hex(randomblob(2))),2) || '-' || substr('89ab',abs(random()) % 4 + 1, 1) || substr(lower(hex(randomblob(2))),2) || '-' || lower(hex(randomblob(6))));
CREATE UNIQUE INDEX idx_workers_uuid ON workers(uuid); 