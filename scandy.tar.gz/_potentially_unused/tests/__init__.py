"""
Test-Paket für Scandy
""" 